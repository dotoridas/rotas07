import { Injectable, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { Usuario } from './usuario';
@Injectable()
export class AuthService {

  private usuarioAutenticado: boolean = false;
  mostrarMenuEmmiter = new EventEmitter();

  constructor(private router: Router) { }

  fazerLogin(usuario: Usuario){
    if((usuario.nome==='usuario@email.com') == (usuario.senha == '123')){
      
      this.usuarioAutenticado=true;
      this.router.navigate(['/']);
      this.mostrarMenuEmmiter.emit(true);
    }else{
      this.usuarioAutenticado=false;
      this.mostrarMenuEmmiter.emit(false);
    }
  }

  isUsuarioAutenticado(){
    return this.usuarioAutenticado;
  }

}
