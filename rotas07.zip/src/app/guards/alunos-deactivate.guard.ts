import { CanDeactivate, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { Injectable } from "@angular/core";
import { AlunosFormComponent } from "../alunos/alunos-form/alunos-form.component";
import { Observable } from "rxjs/Observable";
import { IformDeactivate } from "./iform-deactivate";

@Injectable()
export class AlunosDeactivateGuard implements CanDeactivate<IformDeactivate> {

  constructor() { }

  canDeactivate(
      component: IformDeactivate,
      route: ActivatedRouteSnapshot, 
      state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean{
   console.log("guarde de deactivate");
   
    return component.podeMudar();
  }

}


