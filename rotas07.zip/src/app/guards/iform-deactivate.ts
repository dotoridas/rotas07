

export interface IformDeactivate {
    podeMudar();
}