import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { Route, ActivatedRoute } from '@angular/router';
import { AlunosService } from '../alunos.service';
import { IformDeactivate } from '../../guards/iform-deactivate';

@Component({
  selector: 'app-alunos-form',
  templateUrl: './alunos-form.component.html',
  styleUrls: ['./alunos-form.component.css']
})
export class AlunosFormComponent implements OnInit, IformDeactivate {

  subscribe: Subscription;
  id: number;
  aluno: {};
  private formMudou: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private alunosService: AlunosService
  ) {  }

    ngOnInit() {
      this.subscribe = this.route.params.subscribe(
        (params: any)=>{
          let id = params['id'];
          this.aluno = this.alunosService.getAluno(id);
        } 
      )
    }

    ngOnDestroy(){
      this.subscribe.unsubscribe;
    }

    onInput(){
      this.formMudou = true;
      console.log(this.formMudou)
    }

    podeMudarRota(){
      if(this.formMudou){
        confirm("Tem a certeza que deseja mudar de sair da pagina")
;      }
      return true;
    }

    podeMudar(){
      this.podeMudarRota();
    }
}



