import { Injectable } from "@angular/core";

@Injectable()
export class CursosSevice{

    constructor(){
            console.log('CursosSevice')
    }

    cursos: string[] = ['Angular','Java','Spring Boot'];
    
    getCursos(){
        return this.cursos;
    }

    addCurso(curso: string){
        this.cursos.push(curso);
    }




}