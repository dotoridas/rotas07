import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { CursosSevice } from '../cursos/cursos.service';
import { CursosComponent } from './cursos.component';

@NgModule({
  declarations: [
    CursosComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    CursosComponent
  ],
  providers: [
   // CursosSevice
  ]
})
export class CursosModule { }
